#include "relief_catalog.h" 
//default constructor, arg constructor, destructor, setters, getters,  and if match function for the respective donation type node
food_node::food_node(): next(NULL)
{}
food_node::food_node(const food &src): food(src), next(NULL)
{
} 
void food_node::set(food_node * next)
{
	this->next = next;			
}

food_node* food_node::get()
{
	return next;
}
bool food_node::food_match(const char* to_compare)
{
	if(strcmp(to_compare,food_type)==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}


supplies_node::supplies_node(): next(NULL)
{}
supplies_node::supplies_node(const supplies &src): supplies(src), next(NULL)
{
} 
void supplies_node::set(supplies_node * next)// setters set the current next to the object next
{
	this->next = next;			
}

supplies_node* supplies_node::get()//getters get this current next
{
	return next;
}
bool supplies_node::supplies_match(const char* to_compare)
{
	if(strcmp(to_compare,supplies_type)==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

clothing_node::clothing_node(): next(NULL)
{}
clothing_node::clothing_node(const clothing &src): clothing(src), next(NULL)
{
} 
void clothing_node::set(clothing_node * next)// setters set the current next to the object next
{
	this->next = next;			
}

clothing_node* clothing_node::get()//getters get this current next
{
	return next;
}
bool clothing_node::clothing_match(const char* to_compare)
{
	if(strcmp(to_compare,clothing_type)==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

relief_catalog::relief_catalog()
{
	f_rear = NULL;
	s_rear = NULL;
	c_rear = NULL;
}
relief_catalog::~relief_catalog()
{
	remove_all_food(f_rear->get());
	remove_all_supplies(s_rear->get());
	remove_all_clothing(c_rear->get());
	
}

// function to add a new node to the list of its respective donation type
void relief_catalog::add_food(const food & to_add)
{
	if(!f_rear)
	{
		f_rear = new food_node(to_add);
		f_rear->set(f_rear);		
		return;
	}
	food_node * temp= new food_node(to_add);	
	temp->set(f_rear->get());
	f_rear->set(temp);
	
	
}
void relief_catalog::add_supplies(const supplies & to_add)
{
	if(!s_rear)
	{
		s_rear = new supplies_node(to_add);
		s_rear->set(s_rear);		
		return;
	}
	supplies_node * temp= new supplies_node(to_add);	
	temp->set(s_rear->get());
	s_rear->set(temp);
	
	
}
void relief_catalog::add_clothing(const clothing & to_add)
{
	if(!c_rear)
	{
		c_rear = new clothing_node(to_add);
		c_rear->set(c_rear);		
		return;
	}
	clothing_node * temp= new clothing_node(to_add);	
	temp->set(c_rear->get());
	c_rear->set(temp);
	
	
}
// function to display every node of the list of its respective donation type
void relief_catalog::display_food()
{
	if(!f_rear)
		return;
	display_food(f_rear->get());
}

void relief_catalog::display_food(food_node * f_rear)
{
	if(this->f_rear == f_rear)
	{
		f_rear->display();		
		return;
	}
	f_rear->display();
	display_food(f_rear->get());
}

void relief_catalog::display_supplies()
{
	if(!s_rear)
		return;
	display_supplies(s_rear->get());
}

void relief_catalog::display_supplies(supplies_node * s_rear)
{
	if(this->s_rear == s_rear)
	{
		s_rear->display();		
		return;
	}
	s_rear->display();
	display_supplies(s_rear->get());
}


void relief_catalog::display_clothing()
{
	if(!c_rear)
		return;
	display_clothing(c_rear->get());
}

void relief_catalog::display_clothing(clothing_node * c_rear)
{
	if(this->c_rear == c_rear)
	{
		c_rear->display();		
		return;
	}
	c_rear->display();
	display_clothing(c_rear->get());
}
// function to remove every node of the list of its respective donation type
void relief_catalog::remove_all_food(food_node *f_rear)
{
	if(this->f_rear == f_rear)		
	{
		delete f_rear;
		f_rear = NULL;
		return;	
	}
	food_node * temp = f_rear->get();
	delete f_rear;
	remove_all_food(f_rear->get());
}



void relief_catalog::remove_all_supplies(supplies_node * s_rear)
{
	if(this->s_rear == s_rear)		
	{
		delete s_rear;
		s_rear = NULL;
		return;	
	}
	supplies_node * temp = s_rear->get();
	delete s_rear;
	remove_all_supplies(s_rear->get());
}
void relief_catalog::remove_all_clothing(clothing_node * c_rear)
{
	if(this->c_rear == c_rear)		
	{
		delete c_rear;
		c_rear = NULL;
		return;	
	}
	clothing_node * temp = c_rear->get();
	delete c_rear;
	remove_all_clothing(c_rear->get());
}

// function to remove a specific  node in the list of its respective donation type
void relief_catalog::remove_food(const char * food_type)
{
	if(!f_rear)
		return;
	remove_food(f_rear,f_rear->get(),  food_type);
}
void relief_catalog::remove_food(food_node * f_prev, food_node * f_rear, const char * food_type)
{
	if(this->f_rear == f_rear)
	{
		if(f_rear->food_match(food_type)==true)
		{
			f_prev->set(f_rear->get());
			delete f_rear;
			f_rear = f_prev;
			this->f_rear = f_rear;
		}
		return;
	}
	if(f_rear->food_match(food_type)==true)

	{
		f_prev->set(f_rear->get());
		delete f_rear;
		f_rear = f_prev->get();
	}
	remove_food(f_prev->get(), f_rear->get(), food_type);
}
void relief_catalog::remove_clothing(const char * clothing_type)
{
	if(!c_rear)
		return;
	remove_clothing(c_rear,c_rear->get(),  clothing_type);
}
void relief_catalog::remove_clothing(clothing_node * c_prev, clothing_node * c_rear, const char * clothing_type)
{
	if(this->c_rear == c_rear)
	{
		if(c_rear->clothing_match(clothing_type)==true)
		{
			c_prev->set(c_rear->get());
			delete c_rear;
			c_rear = c_prev;
			this->c_rear = c_rear;
		}
		return;
	}
	if(c_rear->clothing_match(clothing_type)==true)

	{
		c_prev->set(c_rear->get());
		delete c_rear;
		c_rear = c_prev->get();
	}
	remove_clothing(c_prev->get(), c_rear->get(), clothing_type);
}
void relief_catalog::remove_supplies(const char * supplies_type)
{
	if(!s_rear)
		return;
	remove_supplies(s_rear,s_rear->get(),  supplies_type);
}
void relief_catalog::remove_supplies(supplies_node * s_prev, supplies_node * s_rear, const char * supplies_type)
{
	if(this->s_rear == s_rear)
	{
		if(s_rear->supplies_match(supplies_type)==true)
		{
			s_prev->set(s_rear->get());
			delete s_rear;
			s_rear = s_prev;
			this->s_rear = s_rear;
		}
		return;
	}
	if(s_rear->supplies_match(supplies_type)==true)

	{
		s_prev->set(s_rear->get());
		delete s_rear;
		s_rear = s_prev->get();
	}
	remove_supplies(s_prev->get(), s_rear->get(), supplies_type);
}	
