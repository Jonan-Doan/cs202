#pragma once
#include <iostream>
#include <string.h>
/* Jonan Doan
This assignment prompt the user to type in a food, supply, or clothing and it will put the data the
user has inputted into a list so that the user can display it later. The user will also have
the option to remove the type donation if they wanted to.
*/

//allocate and deallocate the name associated with the donation
class donation
{
	public:
		donation();
		donation(const char * a_name);
		donation(const donation & src);
		~donation();
	protected:
		char * a_name;
};
//allocate and deallocate the food type associated with the food donation
class food: public donation
{
	public:
		food();
		food(const char * food_type, int expiration_date, const char * a_name);
		food(const food & src);
		~food();
		void display();
	protected:
		char * food_type;
		int expiration_date;
};
//allocate and deallocate the supplies type associated with the supplies donation
class supplies: public donation
{
	public:
		supplies();
		supplies(const char * supplies_type, const char * a_name);
		supplies(const supplies & src);
		~supplies();
		void display();
	protected:
		char * supplies_type;
};
//allocate and deallocate the supplies type associated with the supply donation
class clothing: public donation
{
	public:
		clothing();
		clothing(const char * clothing_type, const char * a_name);
		clothing(const clothing & src);
		~clothing();
		void display();
	protected:
		char * clothing_type;
};
