#include "donation.h"
using namespace std;

//allocate name to null
donation::donation() :a_name(NULL)
{
}
//allows the data member a_name to be initialize to the same size as the input being pass in
donation::donation(const char * a_name)
{
	this->a_name = new char [strlen(a_name)+1];
	strcpy (this->a_name, a_name);
}
// copy the src data to the data member 
donation::donation(const donation & src)
{
	a_name = new char[strlen(src.a_name)+1];
	strcpy(a_name, src.a_name);
}
//deallocate data member name
donation::~donation()
{
	if(a_name)
	{
		delete a_name;
		a_name = NULL;
	}
}
//allocate food_type to null and allocate expiration date
food::food():food_type(NULL), expiration_date(0)
{
}

//allows the data member food_type to be initialize to the same size as the input being pass in and invoke the base class destructor and constructor
food::food(const char * food_type, int expiration_date, const char  * a_name):donation(a_name), expiration_date(expiration_date)
{
	this->food_type = new char [strlen(food_type)+1];
	strcpy (this->food_type, food_type);
}


// copy the src data to the data member 
food::food(const food & src):donation(src),expiration_date(src.expiration_date)
{
	food_type = new char[strlen(src.food_type)+1];
	strcpy(food_type, src.food_type);
}
// deallocate food_type
food::~food()
{
	if(food_type)
	{
		delete food_type;
		food_type = NULL;
	}
}

//allocate supplies_type
supplies::supplies():supplies_type(NULL)
{
}

//allows the data member supplies_type to be initialize to the same size as the input being pass in and invoke the base class destructor and constructor
supplies::supplies(const char * supplies_type, const char * a_name):donation(a_name)
{
	this->supplies_type = new char [strlen(supplies_type)+1];
	strcpy(this->supplies_type, supplies_type);
}	
// copy the src data to the data member 
supplies::supplies(const supplies & src):donation(src)
{
	supplies_type = new char[strlen(src.supplies_type)+1];
	strcpy(supplies_type, src.supplies_type);
}
//deallocate supply_type
supplies::~supplies()
{
	if(supplies_type)
	{
		delete supplies_type;
		supplies_type = NULL;
	}
}

//allocate clothing_type
clothing::clothing():clothing_type(NULL)
{
}
//allows the data member clothing_type to be initialize to the same size as the input being pass in and invoke the base class destructor and constructor
clothing::clothing(const char * clothing_type, const char * a_name): donation(a_name)
{
	this->clothing_type = new char [strlen(clothing_type) +1];
	strcpy(this->clothing_type, clothing_type);
}

// copy the src data to the data member 
clothing::clothing(const clothing & src):donation(src)
{
	clothing_type = new char[strlen(src.clothing_type)+1];
	strcpy(clothing_type, src.clothing_type);

}
//deallocate clothing_type
clothing::~clothing()
{
	if(clothing_type)
	{
		delete clothing_type;
		clothing_type = NULL;
	}
}

//display function for food, supplies, clothing  while also displaying the name associated to the donation type
void food::display()
{
	if(a_name)
		cout<<"Name: "<<a_name<<endl;
	if(food_type)
		cout<< "Type of food: "<<food_type<<endl;
	cout<< "Expiration date: "<<expiration_date<<endl;
}


void supplies::display()
{
	if(a_name)
		cout<<"Name: "<<a_name<<endl;

	if(supplies_type)
		cout<< "Type of supply: "<<supplies_type<<endl;
}

void clothing::display()
{
	if(a_name)
		cout<<"Name: "<<a_name<<endl;
	if(clothing_type)
		cout<< "Type of clothing: "<<clothing_type<<endl;
}
