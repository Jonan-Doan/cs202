#pragma once
#include "donation.h"
//three node class that is a container for either food, supply, clothing
class food_node: public food
{
	private:
		food_node * next;
	public:
		food_node();
		food_node(const food &src);
		void set(food_node * next);
		bool food_match(const char* to_compare);
		food_node * get();
		
};
class supplies_node: public supplies 
{
	private:
		supplies_node * next;
	public:
		supplies_node();
		supplies_node(const supplies &src);
		void set(supplies_node * next);
		bool supplies_match(const char* to_compare);
		supplies_node * get();
		
};
class clothing_node: public clothing 
{
	private:
		clothing_node * next;
	public:
		clothing_node();
		clothing_node(const clothing &src);
		void set(clothing_node * next);
		bool clothing_match(const char* to_compare);
		clothing_node * get();
		
};
//manages the list of food, clothing, supply implementation
class relief_catalog
{
	public:
		relief_catalog();
		~relief_catalog();
		void add_food(const food & to_add);
		void add_supplies(const supplies & to_add);
		void add_clothing(const clothing & to_add);
		void remove_food(const char * food_type);
		void remove_supplies(const char * supplies_type);
		void remove_clothing(const char * clothing_type);

		void display_food();
		void display_supplies();
		void display_clothing();
		
	protected:
		food_node * f_rear;
		supplies_node * s_rear;	
		clothing_node * c_rear;	
		void remove_food(food_node * f_prev, food_node * f_rear, const char * food_type);
		void remove_supplies(supplies_node * s_prev, supplies_node * s_rear, const char * supplies_type);
		void remove_clothing(clothing_node * c_prev, clothing_node * c_rear, const char * clothing_type);
		void display_food(food_node * f_rear);
		void display_supplies(supplies_node * s_rear);
		void display_clothing(clothing_node * c_rear);
		void remove_all_food(food_node *f_rear);
		void remove_all_supplies(supplies_node *s_rear);
		void remove_all_clothing(clothing_node *c_rear);
		
		
};
