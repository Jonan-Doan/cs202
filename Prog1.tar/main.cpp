#include "donation.h"
#include "relief_catalog.h"
using namespace std;
const int MAX = 100;

int main()
{
	// data type that will be used to either hold the data, accomplish what the user want to accomplish, and also be the class object so that the function can be called.
	char choice;
	char response;
	char food_input[MAX];
	char supplies_input[MAX];
	char clothing_input[MAX];
	char name_input[MAX];
	int ex_date;
	relief_catalog cat;
	
	//accomplish task as long as the user want to quit
 	do
	{ 
		  cout<< "If you want to add a new donation please click A, If you want to remove a new donation click R, if you want to display a specific type of donation please type D."<<endl<<endl;
		  cin>>choice;
		  cin.ignore(MAX, '\n');
		  choice=toupper(choice);
		  if(choice == 'A')//if the user want to insert
		  {
			cout<< "Please type F if you want to add a new food to the donation, Please type S if you want to add a new supply to the donation,"<<endl
			<<"Please type C if you want to add a new clothing to the donation."<<endl<<endl;
			cin>>response;
			cin.ignore(MAX, '\n');
			response = toupper(response);
			if(response == 'F') // if the user want to add a food type
			{
				cout<<"PLease type a name to add alongside the food"<<endl;
				cin.get(name_input, MAX, '\n'); cin.ignore(MAX, '\n');
				cout<<"Please type food to add"<<endl;
				cin.get(food_input, MAX, '\n'); cin.ignore(MAX, '\n');
				cout<<"Please type an expiration date in numbers(ex October 21, 2020 = 10212020)"<<endl;
				cin>>ex_date;
				food food_to_add = food(food_input, ex_date, name_input); 
				cat.add_food(food_to_add);

			}
			if(response == 'S')//if the user want to add a supply type
			{
				cout<<"PLease type a name to add alongside the supplies"<<endl;
				cin.get(name_input, MAX, '\n'); cin.ignore(MAX, '\n');
				cout<<"Please type supplies to add"<<endl;
				cin.get(supplies_input, MAX, '\n'); cin.ignore(MAX, '\n');
				supplies supplies_to_add = supplies(supplies_input, name_input);
				cat.add_supplies(supplies_to_add);
				
			}
			if(response == 'C')//if the user want to add a clothing type
			{
			
				cout<<"PLease type a name to add alongside the clothing"<<endl;
				cin.get(name_input, MAX, '\n'); cin.ignore(MAX, '\n');
				cout<<"Please type clothing to add"<<endl;
				cin.get(clothing_input, MAX, '\n'); cin.ignore(MAX, '\n');
				clothing clothing_to_add= clothing(clothing_input, name_input);
				cat.add_clothing(clothing_to_add);
			}
				
  		  }
		  if(choice == 'R')// if the user want to remove
		  {
			cout<< "Please type F if you want to remove a food of the donation, Please type S if you want to remove a  supply of the donation,"<<endl
			<<"Please type C if you want to remove a clothing of the donation."<<endl<<endl;
			cin>>response;
			cin.ignore(MAX, '\n');
			response = toupper(response);
			if(response == 'F')// remove food_type
			{
				cout<<"Please type food to remove"<<endl;
				cin.get(food_input, MAX, '\n'); cin.ignore(MAX, '\n');
				cat.remove_food(food_input);

			}
			if(response == 'S')// remove supply_type
			{
				cout<<"Please type supplies to add"<<endl;
				cin.get(supplies_input, MAX, '\n'); cin.ignore(MAX, '\n');
				cat.remove_supplies(supplies_input);
				
			}
			if(response == 'C')// remove clothing_type
			{
			
				cout<<"Please type clothing to add"<<endl;
				cin.get(clothing_input, MAX, '\n'); cin.ignore(MAX, '\n');
				cat.remove_clothing(clothing_input);
			}
			
		  }
		 if(choice =='D')//if the user want to display
		 {
			cout<< "Please type F if you want to display a food of the donation, Please type S if you want to display a  supply of the donation,"<<endl
			<<"Please type C if you want to display a clothing of the donation."<<endl<<endl;
			cin>>response;
			cin.ignore(MAX, '\n');
			response = toupper(response);
			if(response == 'F')//display food
			{
				cat.display_food();
			}
			if(response == 'S')//display supply
			{
				cat.display_supplies();
			}
			if(response == 'C')//display clothing
			{
				cat.display_clothing();
			}
		 } 
	}while(choice != 'Q');

	return 0;
}
